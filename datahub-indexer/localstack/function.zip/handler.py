def handler(event, context):
    print(event)
    return event